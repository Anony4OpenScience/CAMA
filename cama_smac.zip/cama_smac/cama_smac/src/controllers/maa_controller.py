from modules.agents import REGISTRY as agent_REGISTRY
from components.action_selectors import REGISTRY as action_REGISTRY
import torch as th
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import os
import math


class MAAMAC(nn.Module):
    def __init__(self, scheme, groups, args):
        super(MAAMAC, self).__init__()
        self.n_agents = args.n_agents
        self.agents_num_for_model = 1
        self.n_adv_agents = args.n_adv_agents
        self.args = args

        self.device = th.device("cuda" if getattr(args, "use_cuda", False) and th.cuda.is_available() else "cpu")
        input_shape = self._get_input_shape(scheme)
        self.state_shape = scheme["state"]["vshape"]
        maa_input_shape = self._get_maa_input_shape(scheme)
        oracle_input_shape = self._get_oracle_input_shape(scheme)
        obs_shape = scheme["obs"]["vshape"]  


        d_model = obs_shape
        nhead = getattr(args, "collusion_nhead")
        dim_ff = getattr(args, "fusion_ff_dim", d_model * 4)
        num_layers = getattr(args, "fusion_nlayers", 2)
        dropout = getattr(args, "fusion_dropout", 0.0)
        
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_ff,
            dropout=dropout,
            batch_first=True,   # [bs, n_adv, dim]
            activation="relu",
        )
        self.fusion_encoder = nn.TransformerEncoder(
            encoder_layer,
            num_layers=num_layers
        )


        self.fusion_alpha_max = getattr(args, "collusion_alpha_max")
        self.fusion_alpha = 0.0 
        self.last_concat_features = None

        self.stealth_mlp = nn.Sequential(
            nn.Linear(obs_shape, 256),
            nn.LayerNorm(256),
            nn.ReLU(),
            nn.Dropout(0.1),

            nn.Linear(256, 128),
            nn.LayerNorm(128),
            nn.ReLU(),
            nn.Dropout(0.1),

            nn.Linear(128, 1)
        ).to(self.device)
        self.stealth_optimizer = optim.Adam(self.stealth_mlp.parameters(), lr=1e-3)

        map_name = self.args.env_args.get("map_name", "unknown_map")
        n_adv = getattr(self.args, "n_adv_agents", "unknown_adv")

        load_dir = os.path.join(
            ".../models",
            map_name,
            "stealth",
            f"n_adv_{n_adv}"
        )
        load_path = os.path.join(load_dir, "mlp.pt")

        if os.path.exists(load_path):
            self.stealth_mlp.load_state_dict(
                th.load(load_path, map_location=self.device)
            )
            print(f"Stealth MLP parameters successfully loaded from {load_path}")
        else:
            print(f"No Stealth MLP ({load_path})")



        self._build_agents(input_shape, maa_input_shape, oracle_input_shape)
        self.agent_output_type = args.agent_output_type

        self.action_selector = action_REGISTRY[args.action_selector](args)
        self.hidden_states = None
        self.maa_hidden_states = None
        self.oracle_hidden_states = None


    def set_fusion_alpha(self, alpha: float):

        alpha = float(alpha)
        alpha = max(0.0, min(1.0, alpha))  
        self.fusion_alpha = alpha * self.fusion_alpha_max


    def fusion_params(self):
        return list(self.fusion_encoder.parameters())

 
    def transformer_fuse(self, adv_obs: th.Tensor) -> th.Tensor:

        bs, n_adv, dim = adv_obs.shape
        device = adv_obs.device


        alive_mask = (adv_obs.abs().sum(dim=-1) > 0)          # [bs, n_adv]
        alive_any = alive_mask.any(dim=1)                     # [bs]
        fused = adv_obs.clone()

 
        if not alive_any.any():
            return fused

  
        valid_idx = alive_any
        valid_obs = adv_obs[valid_idx]        # [bs_valid, n_adv, dim]
        valid_alive = alive_mask[valid_idx]   # [bs_valid, n_adv]


        key_padding_mask = ~valid_alive       # [bs_valid, n_adv]


        fused_valid = self.fusion_encoder(
            valid_obs,
            src_key_padding_mask=key_padding_mask
        )

        if self.fusion_alpha > 0:
            delta = fused_valid - valid_obs
            blended = valid_obs + self.fusion_alpha * delta
        else:
            blended = valid_obs


        blended[key_padding_mask] = 0.0


        fused[valid_idx] = blended
        return fused
 
    def _build_inputs(self, batch, t):
        bs = batch.batch_size


        adv_obs = batch["obs"][:, t, :self.n_adv_agents, :].to(self.device)  # [bs, n_adv, dim]


        fused_obs = self.transformer_fuse(adv_obs)  # [bs, n_adv, dim]


        alive_mask = (adv_obs.abs().sum(dim=-1) > 0)   # [bs, n_adv]
        fused_obs = fused_obs.masked_fill((~alive_mask).unsqueeze(-1), 0.0)

  
        self.last_concat_features = fused_obs.detach()

        inputs = [fused_obs.reshape(bs * self.n_adv_agents, -1)]


        if self.args.obs_last_action:
            if t == 0:
                last_action = th.zeros_like(batch["actions_onehot"][:, t])  # [bs, n_agents, n_actions]
            else:
                last_action = batch["actions_onehot"][:, t - 1]
            last_action = last_action[:, :self.n_adv_agents, :]  
            inputs.append(last_action.reshape(bs * self.n_adv_agents, -1))


        if self.args.obs_agent_id:
            agent_index = th.eye(self.n_agents, device=batch.device).unsqueeze(0).expand(bs, -1, -1)
            agent_index = agent_index[:, :self.n_adv_agents, :]  # [bs, n_adv, n_agents]
            inputs.append(agent_index.reshape(bs * self.n_adv_agents, -1))


        inputs = th.cat(inputs, dim=1)
        return inputs


    def forward_stealth(self):

        if self.last_concat_features is None:
            raise RuntimeError("Please call _build_inputs first to update last_concat_features.")

        feats = self.last_concat_features  # [bs, n_adv, obs]
        bs, n_adv, feat_dim = feats.shape   

        flat = feats.reshape(bs * n_adv, feat_dim)  # or .view(bs*n_adv, feat_dim)

        flat = flat.to(next(self.stealth_mlp.parameters()).device)
        pred_flat = self.stealth_mlp(flat)  # [bs*n_adv, 1]

        pred = pred_flat.view(bs, n_adv, -1)

        return pred  # [bs, n_adv, 1]

  
    def forward(self, ep_batch, t, test_mode=False):

        ep_batch.to(self.device)

        agent_inputs = self._build_inputs(ep_batch, t)
        avail_actions = ep_batch["avail_actions"][:, t].to(self.device)

        agent_outs, self.hidden_states = self.agent(agent_inputs, self.hidden_states)

        if self.agent_output_type == "pi_logits":
            if getattr(self.args, "mask_before_softmax", True):
                reshaped_avail_actions = avail_actions.reshape(ep_batch.batch_size * self.n_adv_agents, -1)
                agent_outs[reshaped_avail_actions == 0] = -1e10
            agent_outs = F.softmax(agent_outs, dim=-1)

        return agent_outs.view(ep_batch.batch_size, self.n_adv_agents, -1)

    def forward_no_softmax(self, ep_batch, t, test_mode=False):
        agent_inputs = self._build_inputs(ep_batch, t)
        avail_actions = ep_batch["avail_actions"][:, t]
        agent_outs, self.hidden_states = self.agent(agent_inputs, self.hidden_states)

        if self.agent_output_type == "pi_logits":
            if getattr(self.args, "mask_before_softmax", True):
                reshaped_avail_actions = avail_actions.reshape(ep_batch.batch_size * self.n_adv_agents, -1)
                agent_outs[reshaped_avail_actions == 0] = -1e10

        return agent_outs.view(ep_batch.batch_size, self.n_adv_agents, -1)

    def forward_maa(self, ep_batch, t, test_mode=False):
        maa_inputs = self._build_maa_inputs(ep_batch, t)
        avail_actions = ep_batch["avail_actions_all"][:, t+1]  # bav
        avail_actions = avail_actions.unsqueeze(1).expand(-1, self.agents_num_for_model, -1, -1)  # bnav
        maa_outs, self.maa_hidden_states = self.maa(maa_inputs, self.maa_hidden_states)

        if self.agent_output_type == "pi_logits":
            if getattr(self.args, "mask_before_softmax", True):
                reshaped_avail_actions = avail_actions.reshape(ep_batch.batch_size * self.agents_num_for_model, -1)
                maa_outs[reshaped_avail_actions == 0] = -1e10
            maa_outs = maa_outs.reshape(ep_batch.batch_size * self.agents_num_for_model * self.n_agents, -1)
            maa_outs = F.softmax(maa_outs, dim=-1)
        return maa_outs.view(ep_batch.batch_size, self.agents_num_for_model, self.n_agents, -1)

    def forward_oracle_nosoftmax(self, ep_batch, t, test_mode=False):
        oracle_inputs = self._build_oracle_inputs(ep_batch, t)
        avail_actions = ep_batch["avail_actions_all"][:, t+1]
        oracle_outs, self.oracle_hidden_states = self.oracle(oracle_inputs, self.oracle_hidden_states)

        if self.agent_output_type == "pi_logits":
            if getattr(self.args, "mask_before_softmax", True):
                reshaped_avail_actions = avail_actions.reshape(ep_batch.batch_size * self.agents_num_for_model, -1)
                oracle_outs[reshaped_avail_actions == 0] = -1e10
            oracle_outs = oracle_outs.reshape(ep_batch.batch_size * self.agents_num_for_model * self.n_agents, -1)
        return oracle_outs.view(ep_batch.batch_size, self.n_agents, -1)

    def forward_oracle_logsoftmax(self, ep_batch, t, test_mode=False):
        oracle_inputs = self._build_oracle_inputs(ep_batch, t)
        avail_actions = ep_batch["avail_actions_all"][:, t+1]
        oracle_outs, self.oracle_hidden_states = self.oracle(oracle_inputs, self.oracle_hidden_states)

        if self.agent_output_type == "pi_logits":
            if getattr(self.args, "mask_before_softmax", True):
                reshaped_avail_actions = avail_actions.reshape(ep_batch.batch_size * self.agents_num_for_model, -1)
                oracle_outs[reshaped_avail_actions == 0] = -1e10
            oracle_outs = oracle_outs.reshape(ep_batch.batch_size * self.agents_num_for_model * self.n_agents, -1)
        oracle_outs = F.log_softmax(oracle_outs, dim=-1)
        return oracle_outs.view(ep_batch.batch_size, self.n_agents, -1)

    def forward_maa_inputs(self, maa_inputs, ep_batch, t, test_mode=False):
        avail_actions = ep_batch["avail_actions_all"][:, t+1]
        avail_actions = avail_actions.unsqueeze(1).expand(-1, self.agents_num_for_model, -1, -1)
        maa_outs, self.maa_hidden_states = self.maa(maa_inputs, self.maa_hidden_states)

        if self.agent_output_type == "pi_logits":
            if getattr(self.args, "mask_before_softmax", True):
                reshaped_avail_actions = avail_actions.reshape(ep_batch.batch_size * self.agents_num_for_model, -1)
                maa_outs[reshaped_avail_actions == 0] = -1e10
            maa_outs = maa_outs.reshape(ep_batch.batch_size * self.agents_num_for_model * self.n_agents, -1)
            maa_outs = F.softmax(maa_outs, dim=-1)
        return maa_outs.view(ep_batch.batch_size, self.agents_num_for_model, self.n_agents, -1)

    def select_actions(self, ep_batch, t_ep, t_env, bs=slice(None), test_mode=False):
        avail_actions = ep_batch["avail_actions"][:, t_ep]
        agent_outputs = self.forward(ep_batch, t_ep, test_mode=test_mode)
        chosen_actions = self.action_selector.select_action(agent_outputs[bs], avail_actions[bs], t_env, test_mode=test_mode)
        return chosen_actions

    def init_hidden(self, batch_size):
        self.hidden_states = self.agent.init_hidden().unsqueeze(0).expand(
            batch_size, self.n_adv_agents, -1
        ).contiguous().view(batch_size * self.n_adv_agents, -1)

    def init_hidden_maa(self, batch_size):
        self.maa_hidden_states = self.maa.init_hidden().unsqueeze(0).expand(
            batch_size, self.agents_num_for_model, -1
        ).contiguous().view(batch_size * self.agents_num_for_model, -1)

    def init_hidden_oracle(self, batch_size):
        self.oracle_hidden_states = self.oracle.init_hidden().unsqueeze(0).expand(
            batch_size, self.agents_num_for_model, -1
        ).contiguous().view(batch_size * self.agents_num_for_model, -1)


    def parameters(self):
        return list(self.agent.parameters())

    def maa_parameters(self):
        return list(self.maa.parameters())
    
    def oracle_parameters(self):
        return list(self.oracle.parameters())


    def load_state(self, other_mac):

        self.agent.load_state_dict(other_mac.agent.state_dict())
        self.maa.load_state_dict(other_mac.maa.state_dict())
        self.oracle.load_state_dict(other_mac.oracle.state_dict())

        if hasattr(self, "fusion_encoder") and hasattr(other_mac, "fusion_encoder"):
            self.fusion_encoder.load_state_dict(other_mac.fusion_encoder.state_dict())
            self.fusion_alpha = getattr(other_mac, "fusion_alpha", 0.0)


    def mac_eval(self):
        self.agent.eval()
        self.maa.eval()
        self.oracle.eval()
        if hasattr(self, "fusion_encoder"):
            self.fusion_encoder.eval()

    def mac_train(self):
        self.agent.train()
        self.maa.train()
        self.oracle.train()
        if hasattr(self, "fusion_encoder"):
            self.fusion_encoder.train()


    def cuda(self):
        self.to("cuda")

    def save_models(self, path):
 
        th.save(self.agent.state_dict(), f"{path}/agent.th")
        th.save(self.maa.state_dict(), f"{path}/maa.th")
        th.save(self.oracle.state_dict(), f"{path}/oracle.th")


        th.save({
            "fusion_encoder": self.fusion_encoder.state_dict(),
            "fusion_alpha": self.fusion_alpha,
        }, f"{path}/fusion.th")

    def load_models(self, path):

        self.agent.load_state_dict(th.load(f"{path}/agent.th", map_location=lambda s, l: s))
        self.maa.load_state_dict(th.load(f"{path}/maa.th", map_location=lambda s, l: s))
        self.oracle.load_state_dict(th.load(f"{path}/oracle.th", map_location=lambda s, l: s))

        try:
            fusion_ckpt = th.load(f"{path}/fusion.th", map_location=lambda s, l: s)
            self.fusion_encoder.load_state_dict(fusion_ckpt["fusion_encoder"])
            self.fusion_alpha = fusion_ckpt.get("fusion_alpha", 0.0)
        except FileNotFoundError:

            pass
        

    def _build_agents(self, input_shape, maa_input_shape, oracle_input_shape):
        self.agent = agent_REGISTRY[self.args.agent](input_shape, self.args)
        self.maa = agent_REGISTRY["maa"](maa_input_shape, self.args)
        self.oracle = agent_REGISTRY["policy_oracle"](oracle_input_shape, self.args)

    def _build_maa_inputs(self, batch, t):
        bs = batch.batch_size
        inputs = batch["state"][:, t].unsqueeze(1).expand(-1, self.agents_num_for_model, -1)
        inputs = inputs.reshape(bs * self.agents_num_for_model, -1)

        actions_onehot = batch["actions_all_onehot"][:, t].reshape(bs, -1)
        actions_onehot = actions_onehot.unsqueeze(1).expand(-1, self.agents_num_for_model, -1)
        actions_onehot = actions_onehot.reshape(bs * self.agents_num_for_model, -1)
        return th.cat([inputs, actions_onehot], dim=1)

    def _build_oracle_inputs(self, batch, t):
        bs = batch.batch_size
        inputs = batch["state"][:, t].unsqueeze(1).expand(-1, self.agents_num_for_model, -1)
        inputs = inputs.reshape(bs * self.agents_num_for_model, -1)

        actions_onehot = batch["actions_all_onehot"][:, t].reshape(bs, -1)
        actions_onehot = actions_onehot.unsqueeze(1).expand(-1, self.agents_num_for_model, -1)
        actions_onehot = actions_onehot.reshape(bs * self.agents_num_for_model, -1)
        return th.cat([inputs, actions_onehot], dim=1)

 
    def _get_input_shape(self, scheme):
        input_shape = scheme["obs"]["vshape"]
        if self.args.obs_last_action:
            input_shape += scheme["actions_onehot"]["vshape"][0]
        if self.args.obs_agent_id:
            input_shape += self.n_agents
        return input_shape

    def _get_maa_input_shape(self, scheme):
        return scheme["state"]["vshape"] + scheme["actions_onehot"]["vshape"][0] * self.args.n_agents

    def _get_oracle_input_shape(self, scheme):
        return scheme["state"]["vshape"] + scheme["actions_onehot"]["vshape"][0] * self.args.n_agents
