import datetime
import os
import pprint
import time
import copy
import threading
import collections
import torch as th
import setproctitle
from types import SimpleNamespace as SN
from utils.logging import Logger
from utils.timehelper import time_left, time_str
from os.path import dirname, abspath

from learners import REGISTRY as le_REGISTRY
from runners import REGISTRY as r_REGISTRY
from controllers import REGISTRY as mac_REGISTRY
from components.episode_buffer import ReplayBuffer
from components.transforms import OneHot
from absl import logging
logging.set_verbosity(logging.ERROR)

def recursive_dict_update(d, u):
    for k, v in u.items():

        if isinstance(v, collections.abc.Mapping):
            d[k] = recursive_dict_update(d.get(k, {}), v)
        else:
            d[k] = v
    return d

def run(_run, _config, _log):
    _config = args_sanity_check(_config, _log)
    _victim_config = copy.deepcopy(_config)
    victim_config = _config.get("victim_args", {})
    _victim_config = recursive_dict_update(_victim_config, victim_config)

    args = SN(**_config)
    args.device = "cuda" if args.use_cuda else "cpu"

    victim_args = SN(**_victim_config)
    victim_args.device = "cuda" if victim_args.use_cuda else "cpu"

    logger = Logger(_log)

    _log.info("Experiment Parameters:")
    experiment_params = pprint.pformat(_config, indent=4, width=1)
    _log.info("\n\n" + experiment_params + "\n")

    try:
        map_name = _config["env_args"]["map_name"]
    except:
        map_name = _config["env_args"]["key"]   
    unique_token = f"{_config['name']}_seed{_config['seed']}_{map_name}_{args.token}"
    
    setproctitle.setproctitle(unique_token)

    args.unique_token = unique_token
    if args.use_tensorboard and not args.evaluate:
        tb_logs_direc = os.path.join(os.getcwd(), "results", "tb_logs")
        tb_exp_direc = os.path.join(tb_logs_direc, "{}").format(unique_token)
        logger.setup_tb(tb_exp_direc)

    logger.setup_sacred(_run)

    if args.mode == "adv_policy" or args.mode == "adv_state":
        run_sequential_adv_policy(args=args, logger=logger, victim_args=victim_args)
    else:
        run_sequential(args=args, logger=logger)


    print("Exiting Main")

    print("Stopping all threads")
    for t in threading.enumerate():
        if t.name != "MainThread":
            print("Thread {} is alive! Is daemon: {}".format(t.name, t.daemon))
            t.join(timeout=1)
            print("Thread joined")

    print("Exiting script")


def run_sequential(args, logger):               

    runner = r_REGISTRY[args.runner](args=args, logger=logger)

    # Set up schemes and groups here
    env_info = runner.get_env_info()
    args.n_agents = env_info["n_agents"]
    args.n_actions = env_info["n_actions"]
    args.state_shape = env_info["state_shape"]

    # Default/Base scheme
    scheme = {
        "state": {"vshape": env_info["state_shape"]},
        "obs": {"vshape": (env_info["obs_shape"]), "group": "agents"},
        "actions": {"vshape": (1,), "group": "agents", "dtype": th.long},
        "avail_actions": {
            "vshape": (env_info["n_actions"],),
            "group": "agents",
            "dtype": th.int,
        },
        "reward": {"vshape": (1,)},
        "terminated": {"vshape": (1,), "dtype": th.uint8},
    }
    groups = {"agents": args.n_agents}
    preprocess = {"actions": ("actions_onehot", [OneHot(out_dim=args.n_actions)])}

    buffer = ReplayBuffer(
        scheme,
        groups,
        args.buffer_size,
        env_info["episode_limit"] + 1,
        preprocess=preprocess,
        device="cpu" if args.buffer_cpu_only else args.device,
    )


    mac = mac_REGISTRY[args.mac](buffer.scheme, groups, args)  

    runner.setup(scheme=scheme, groups=groups, preprocess=preprocess, mac=mac)    

    learner = le_REGISTRY[args.learner](mac, buffer.scheme, logger, args)       #
    if args.use_cuda:
        learner.cuda()



    if args.checkpoint_path != "":          
        timesteps = []         
        timestep_to_load = 0   

        if not os.path.isdir(args.checkpoint_path):    
            logger.console_logger.info(
                "Checkpoint directiory {} doesn't exist".format(args.checkpoint_path)
            )
            return


        for name in os.listdir(args.checkpoint_path):
            full_name = os.path.join(args.checkpoint_path, name)
            # Check if they are dirs the names of which are numbers
            if os.path.isdir(full_name) and name.isdigit():
                timesteps.append(int(name))             

        if args.load_step == 0:
        
            timestep_to_load = max(timesteps)         
        else:                                          
        
            timestep_to_load = min(timesteps, key=lambda x: abs(x - args.load_step))

        model_path = os.path.join(args.checkpoint_path, str(timestep_to_load))

        logger.console_logger.info("Loading model from {}".format(model_path))

        learner.load_models(model_path)
        runner.t_env = timestep_to_load

    if args.evaluate or args.save_replay:
        print("Evaluate!",flush=True)
        runner.log_train_stats_t = runner.t_env
        # Evaluate process
        for _ in range(args.test_nepisode):
            print("test_neppside:")
            runner.run(test_mode=True)
        if args.save_replay:
            runner.save_replay()
        runner.close_env()
        logger.log_stat("episode", runner.t_env, runner.t_env)
        logger.print_recent_stats()
        logger.console_logger.info("Finished Evaluation")
        return

    # start training
    episode = 0
    last_test_T = -args.test_interval - 1
    last_log_T = 0
    model_save_time = 0

    start_time = time.time()
    last_time = start_time

    logger.console_logger.info("Beginning training for {} timesteps".format(args.t_max))

    while runner.t_env <= args.t_max:
        # Run for a whole episode at a time
        episode_batch = runner.run(test_mode=False)
        buffer.insert_episode_batch(episode_batch)

        if buffer.can_sample(args.batch_size):
            episode_sample = buffer.sample(args.batch_size)

            # Truncate batch to only filled timesteps
            max_ep_t = episode_sample.max_t_filled()
            episode_sample = episode_sample[:, :max_ep_t]

            if episode_sample.device != args.device:
                episode_sample.to(args.device)

            learner.train(episode_sample, runner.t_env, episode)

        # Execute test runs once in a while
        n_test_runs = max(1, args.test_nepisode // runner.batch_size)
        if (runner.t_env - last_test_T) / args.test_interval >= 1.0:

            logger.console_logger.info(
                "t_env: {} / {}".format(runner.t_env, args.t_max)
            )
            logger.console_logger.info(
                "Estimated time left: {}. Time passed: {}".format(
                    time_left(last_time, last_test_T, runner.t_env, args.t_max),
                    time_str(time.time() - start_time),
                )
            )
            last_time = time.time()

            last_test_T = runner.t_env
            for _ in range(n_test_runs):
                runner.run(test_mode=True)

        if args.save_model and (
            runner.t_env - model_save_time >= args.save_model_interval
            or model_save_time == 0
        ):
            model_save_time = runner.t_env
            save_path = os.path.join(
                args.local_results_path, 
                "models", 
                args.unique_token, 
                f"adv_{args.n_adv_agents}", 
                str(runner.t_env)
            )

            os.makedirs(save_path, exist_ok=True)
            logger.console_logger.info("Saving models to {}".format(save_path))


            learner.save_models(save_path)

        episode += args.batch_size_run

        if (runner.t_env - last_log_T) >= args.log_interval:
            logger.log_stat("episode", episode, runner.t_env)
            logger.print_recent_stats()
            last_log_T = runner.t_env

    runner.close_env()
    logger.console_logger.info("Finished Training")


def run_sequential_adv_policy(args, logger, victim_args):     
    # Init runner so we can get env info
    runner = r_REGISTRY[args.runner](args=args, logger=logger)
    # Set up schemes and groups here
    env_info = runner.get_env_info()   
    print("env_info:", env_info)
    print("env_info['obs_shape']:", env_info["obs_shape"])
    args.n_agents = env_info["n_agents"]
    args.n_adv_agents = len(args.adv_agent_ids)
    args.n_actions = env_info["n_actions"]
    args.state_shape = env_info["state_shape"]
    victim_args.n_agents = env_info["n_agents"]
    victim_args.n_adv_agents = len(args.adv_agent_ids)
    victim_args.n_actions = env_info["n_actions"]
    victim_args.state_shape = env_info["state_shape"]
    
    scheme = {
        "state": {"vshape": env_info["state_shape"]},
        "obs": {"vshape": env_info["obs_shape"]  , "group": "agents"},
        "actions": {"vshape": (1,), "group": "agents", "dtype": th.long},
        "adv_agent_mask": {"vshape": (1,), "group": "agents", "dtype": th.bool},
        "avail_actions": {
            "vshape": (env_info["n_actions"],),
            "group": "agents",
            "dtype": th.int,
        },
        "reward": {"vshape": (1,)},
        "terminated": {"vshape": (1,), "dtype": th.uint8},
    }
    # for research use, adv_scheme contains all the variables
    adv_scheme = {                          
        "state": {"vshape": env_info["state_shape"]},  
        "obs": {"vshape": env_info["obs_shape"] , "group": "adv_agents"}, 
        "obs_all": {"vshape": env_info["obs_shape"]  , "group": "agents"},

        "actions": {"vshape": (1,), "group": "adv_agents", "dtype": th.long},
        "actions_all": {"vshape": (1,), "group": "agents", "dtype": th.long},
        "adv_agent_mask": {"vshape": (1,), "group": "agents", "dtype": th.bool},
        "benign_logit": {
            "vshape": (env_info["n_actions"],),
            "group": "adv_agents",
        },
        "avail_actions": {
            "vshape": (env_info["n_actions"],),
            "group": "adv_agents",
            "dtype": th.int,
        },
        "avail_actions_all": {
            "vshape": (env_info["n_actions"],),
            "group": "agents",
            "dtype": th.int,
        },
        "reward": {"vshape": (1,)},
        "reward_positive": {"vshape": (1,)},
        "reward_negative": {"vshape": (1,)},
        "terminated": {"vshape": (1,), "dtype": th.uint8},
    }
    groups = {"agents": args.n_agents, "adv_agents": args.n_adv_agents}
    preprocess = {"actions": ("actions_onehot", [OneHot(out_dim=args.n_actions)])}
    adv_preprocess = {
        "actions": ("actions_onehot", [OneHot(out_dim=args.n_actions)]),
        "actions_all": ("actions_all_onehot", [OneHot(out_dim=args.n_actions)]),
    }
    buffer = ReplayBuffer(
        scheme,
        groups,
        victim_args.buffer_size,
        env_info["episode_limit"] + 1,
        preprocess=preprocess,
        device="cpu" if args.buffer_cpu_only else args.device,
    )
    adv_buffer = ReplayBuffer(
        adv_scheme,
        groups,
        args.buffer_size,
        env_info["episode_limit"] + 1,
        preprocess=adv_preprocess,
        device="cpu" if args.buffer_cpu_only else args.device,
    )
    # Setup multiagent controller here
    mac = mac_REGISTRY[victim_args.mac](buffer.scheme, groups, victim_args)
    adv_mac = mac_REGISTRY[args.mac](adv_buffer.scheme, groups, args)
    # Give runner the scheme
    runner.setup(scheme=scheme, groups=groups, preprocess=preprocess, mac=mac)
    runner.setup_adv(scheme=adv_scheme, groups=groups, preprocess=adv_preprocess, mac=adv_mac)
    # Learner
    learner = le_REGISTRY[args.learner](adv_mac, adv_buffer.scheme, logger, args)
    if args.use_cuda:
        learner.cuda()
        mac.cuda()
    

    runner.adv_critic = learner.critic


    if victim_args.checkpoint_path != "":
        timesteps = []
        timestep_to_load = 0

        if not os.path.isdir(victim_args.checkpoint_path):
            logger.console_logger.info(
                "Checkpoint directiory {} doesn't exist".format(victim_args.checkpoint_path)
            )
            return

        # Go through all files in args.checkpoint_path
        for name in os.listdir(victim_args.checkpoint_path):
            full_name = os.path.join(victim_args.checkpoint_path, name)
            # Check if they are dirs the names of which are numbers
            if os.path.isdir(full_name) and name.isdigit():
                timesteps.append(int(name))

        if victim_args.load_step == 0:
            # choose the max timestep
            timestep_to_load = max(timesteps)
        else:
            # choose the timestep closest to load_step
            timestep_to_load = min(timesteps, key=lambda x: abs(x - victim_args.load_step))

        model_path = os.path.join(victim_args.checkpoint_path, str(timestep_to_load))

        logger.console_logger.info("Loading model from {}".format(model_path))
        mac.load_models(model_path)

    # Loading adversarial checkpoints
    if args.checkpoint_path != "":
        timesteps = []
        timestep_to_load = 0

        if not os.path.isdir(args.checkpoint_path):
            logger.console_logger.info(
                "Adv checkpoint directiory {} doesn't exist".format(args.checkpoint_path)
            )
            return

        # Go through all files in args.checkpoint_path
        for name in os.listdir(args.checkpoint_path):
            full_name = os.path.join(args.checkpoint_path, name)
            # Check if they are dirs the names of which are numbers
            if os.path.isdir(full_name) and name.isdigit():
                timesteps.append(int(name))

        if args.load_step == 0:
            # choose the max timestep
            timestep_to_load = max(timesteps)
        else:
            # choose the timestep closest to load_step
            timestep_to_load = min(timesteps, key=lambda x: abs(x - args.load_step))

        model_path = os.path.join(args.checkpoint_path, str(timestep_to_load))

        logger.console_logger.info("Loading adversarial model from {}".format(model_path))

        learner.load_models(model_path)
        runner.t_env = timestep_to_load

    if args.evaluate or args.save_replay:
        runner.log_train_stats_t = runner.t_env
        episode = 0
        # Evaluate sequential
        for _ in range(args.test_nepisode):
            _, episode_batch = runner.run_adv_policy(test_mode=True)
            adv_buffer.insert_episode_batch(episode_batch)

            if adv_buffer.can_sample(args.batch_size):
                episode_sample = adv_buffer.sample(args.batch_size)

                # Truncate batch to only filled timesteps
                max_ep_t = episode_sample.max_t_filled()
                episode_sample = episode_sample[:, :max_ep_t]

                if episode_sample.device != args.device:
                    episode_sample.to(args.device)

                learner.train(episode_sample, runner.t_env, episode)
        
        if args.save_replay:
            runner.save_replay()

        runner.close_env()
        logger.log_stat("episode", runner.t_env, runner.t_env)
        logger.print_recent_stats()
        logger.console_logger.info("Finished Evaluation")
        return

    # start training
    episode = 0
    last_test_T = -args.test_interval - 1
    last_log_T = 0
    model_save_time = 0

    start_time = time.time()
    last_time = start_time

    logger.console_logger.info("Beginning training for {} timesteps".format(args.t_max))

    while runner.t_env <= args.t_max:
        # Run for a whole episode at a time
        _, episode_batch = runner.run_adv_policy(test_mode=False)
        
        adv_buffer.insert_episode_batch(episode_batch)

        if adv_buffer.can_sample(args.batch_size):
            episode_sample = adv_buffer.sample(args.batch_size)

            # Truncate batch to only filled timesteps
            max_ep_t = episode_sample.max_t_filled()
            episode_sample = episode_sample[:, :max_ep_t]

            if episode_sample.device != args.device:
                episode_sample.to(args.device)

            learner.train(episode_sample, runner.t_env, episode)

        # Execute test runs once in a while
        n_test_runs = max(1, args.test_nepisode // runner.batch_size)
        if (runner.t_env - last_test_T) / args.test_interval >= 1.0:

            logger.console_logger.info(
                "t_env: {} / {}".format(runner.t_env, args.t_max)
            )
            logger.console_logger.info(
                "Estimated time left: {}. Time passed: {}".format(
                    time_left(last_time, last_test_T, runner.t_env, args.t_max),
                    time_str(time.time() - start_time),
                )
            )
            last_time = time.time()

            last_test_T = runner.t_env
            for _ in range(n_test_runs):
                runner.run_adv_policy(test_mode=True)

        if args.save_model and (
            runner.t_env - model_save_time >= args.save_model_interval
            or model_save_time == 0
        ):
            model_save_time = runner.t_env
            
            # today = time.strftime("DATE%m%d")
            alpha_str = f"{args.collusion_alpha_max:.1f}"
            map_name = args.env_args["map_name"]
            config_name = args.name
            save_path = os.path.join(
                args.local_results_path, 
                "models", 
                map_name,
                config_name,
                str(runner.t_env)
            )
   
            os.makedirs(save_path, exist_ok=True)
            logger.console_logger.info("Saving models to {}".format(save_path))


            learner.save_models(save_path)

        episode += args.batch_size_run

        if (runner.t_env - last_log_T) >= args.log_interval:
            logger.log_stat("episode", episode, runner.t_env)
            logger.print_recent_stats()
            last_log_T = runner.t_env

    runner.close_env()
    logger.console_logger.info("Finished Training")


def args_sanity_check(config, _log):

    config["use_cuda"] = True # Use cuda whenever possible!
    if config["use_cuda"] and not th.cuda.is_available():
        config["use_cuda"] = False
        _log.warning(
            "CUDA flag use_cuda was switched OFF automatically because no CUDA devices are available!"
        )

    if config["test_nepisode"] < config["batch_size_run"]:
        config["test_nepisode"] = config["batch_size_run"]
    else:
        config["test_nepisode"] = (
            config["test_nepisode"] // config["batch_size_run"]
        ) * config["batch_size_run"]

    return config
